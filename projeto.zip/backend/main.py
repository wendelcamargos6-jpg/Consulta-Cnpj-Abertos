from pathlib import Path

from fastapi import FastAPI, HTTPException, Request
from fastapi.exceptions import RequestValidationError
from fastapi.logger import logger
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

from api.export import router as export_router
from api.health import router as health_router
from api.root import router as root_router
from api.search import router as search_router
from api.test import router as test_router
from services.database_service import DatabaseService

ROOT_DIR = Path(__file__).resolve().parent.parent
STATIC_DIR = ROOT_DIR / "static"

def create_app() -> FastAPI:
    app = FastAPI(title="CNPJ Hunter Pro")
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")
    app.include_router(root_router)
    app.include_router(health_router)
    app.include_router(search_router)
    app.include_router(export_router)
    app.include_router(test_router)

    @app.exception_handler(RequestValidationError)
    async def validation_exception_handler(request: Request, exc: RequestValidationError):
        logger.warning("Validação falhou para %s: %s", request.url, exc.errors())
        return JSONResponse(
            status_code=422,
            content={
                "success": False,
                "message": "Dados de entrada inválidos. Verifique os campos e tente novamente.",
                "errors": exc.errors(),
            },
        )

    @app.exception_handler(HTTPException)
    async def http_exception_handler(request: Request, exc: HTTPException):
        logger.error("HTTP exception em %s: %s", request.url, exc.detail)
        content = {"success": False, "message": exc.detail}
        if isinstance(exc.detail, dict):
            content.update(exc.detail)
        else:
            content["detail"] = exc.detail
        return JSONResponse(status_code=exc.status_code, content=content)

    @app.on_event("startup")
    def startup_event():
        logger.info("Inicializando aplicação CNPJ Hunter Pro")
        DatabaseService.initialize_database()

    return app

app = create_app()
